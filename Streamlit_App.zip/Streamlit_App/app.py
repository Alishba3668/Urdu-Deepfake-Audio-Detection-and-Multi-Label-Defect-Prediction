# app.py

import streamlit as st
import numpy as np
import pandas as pd
import joblib
import torch
import torch.nn as nn

# ---------------------------
# Load models and vectorizer
# ---------------------------
@st.cache_resource
def load_models():
    svm = joblib.load("svm_model.pkl")
    logreg = joblib.load("logreg_model.pkl")
    vectorizer = joblib.load("tfidf_vectorizer.pkl")
    
    # Load DNN model
    class MultiLabelDNN(nn.Module):
        def __init__(self, input_dim, output_dim):
            super(MultiLabelDNN, self).__init__()
            self.fc1 = nn.Linear(input_dim, 128)
            self.fc2 = nn.Linear(128, 64)
            self.out = nn.Linear(64, output_dim)

        def forward(self, x):
            x = torch.relu(self.fc1(x))
            x = torch.relu(self.fc2(x))
            return torch.sigmoid(self.out(x))

    dnn = MultiLabelDNN(1000, 7)  # Update input/output dims if needed
    dnn.load_state_dict(torch.load("dnn_model.pt", map_location=torch.device('cpu')))
    dnn.eval()

    return svm, logreg, dnn, vectorizer

svm_model, logreg_model, dnn_model, tfidf = load_models()

# Your label names (must match model training)
label_names = [
    "type_blocker", "type_regression", "type_bug",
    "type_documentation", "type_enhancement", "type_task", "type_dependency_upgrade"
]

# ---------------------------
# Streamlit UI
# ---------------------------
st.title("🔍 Defect Prediction & Deepfake Detection")

task = st.radio("Choose Task:", ["Software Defect Prediction", "Audio Deepfake Detection"])

# ---------------------------
# Software Defect Prediction
# ---------------------------
if task == "Software Defect Prediction":
    st.subheader("Enter a software defect report:")
    report_input = st.text_area("Bug Report Text")
    model_type = st.selectbox("Select Model", ["Logistic Regression", "SVM", "DNN"])

    if st.button("Predict"):
        if not report_input.strip():
            st.warning("Please enter a report.")
        else:
            vectorized_input = tfidf.transform([report_input]).toarray()

            if model_type == "Logistic Regression":
                probs = logreg_model.predict_proba(vectorized_input)
                preds = (probs >= 0.5).astype(int)
                pred_labels = [label for label, val in zip(label_names, preds[0]) if val == 1]
                st.success(f"Predicted Labels: {pred_labels}")
                st.write("Confidence Scores:")
                st.table(pd.DataFrame({"Label": label_names, "Confidence": probs[0].round(3)}))

            elif model_type == "SVM":
                try:
                    probs = svm_model.decision_function(vectorized_input)
                    probs = 1 / (1 + np.exp(-probs))  # Apply sigmoid
                    preds = (probs >= 0.5).astype(int)
                    pred_labels = [label for label, val in zip(label_names, preds[0]) if val == 1]
                    st.success(f"Predicted Labels: {pred_labels}")
                    st.write("Confidence Scores:")
                    st.table(pd.DataFrame({"Label": label_names, "Confidence": probs[0].round(3)}))
                except AttributeError:
                    st.warning("This SVM model doesn't support confidence scores. Re-train with probability=True.")

            elif model_type == "DNN":
                input_tensor = torch.tensor(vectorized_input, dtype=torch.float32)
                with torch.no_grad():
                    probs = dnn_model(input_tensor).numpy()[0]
                preds = (probs >= 0.5).astype(int)
                pred_labels = [label for label, val in zip(label_names, preds) if val == 1]
                st.success(f"Predicted Labels: {pred_labels}")
                st.write("Confidence Scores:")
                st.table(pd.DataFrame({"Label": label_names, "Confidence": probs.round(3)}))

# ---------------------------
# Audio Deepfake Detection (Placeholder)
# ---------------------------
else:
    st.subheader("Upload an audio file to classify as Deepfake or Bonafide")
    audio_file = st.file_uploader("Choose audio file", type=["wav", "mp3"])

    if audio_file and st.button("Analyze Audio"):
        st.warning("⚠️ Deepfake audio classification model is not integrated yet.")
        st.info("This section is a placeholder. You can integrate your audio model here.")
